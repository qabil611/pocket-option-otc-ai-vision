package com.qabil.otcai

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCapture = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(7, 16, 30))
        }
        val title = TextView(this).apply {
            text = "POCKET OPTION\nOTC AI V2 PRO"
            textSize = 25f
            setTextColor(Color.rgb(40, 217, 161))
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Ekran analizi hazır deyil. Başlamaq üçün icazə ver."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 35, 0, 35)
        }
        val start = Button(this).apply {
            text = "EKRAN ANALİZİNİ BAŞLAT"
            setOnClickListener {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
            }
        }
        val stop = Button(this).apply {
            text = "DAYANDIR"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "Ekran çəkilişi dayandırıldı."
            }
        }
        val note = TextView(this).apply {
            text = "Qeyd: Android ekran paylaşımı icazəsini yalnız özünüz təsdiqləyin. Bu ilkin V2 quruluşu ekran çəkilişinin icazəsini və xidmətini hazırlayır; hələ OTC şamlarını tanımır və CALL/PUT proqnozu vermir. Real analiz ayrıca hazırlanıb sınaqdan keçirilməlidir."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 30, 0, 0)
        }
        layout.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(status)
        layout.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(note)
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra("resultCode", resultCode)
                    putExtra("captureData", data)
                }
                startForegroundService(service)
                status.text = "Ekran çəkilişi aktivdir. OTC qrafikinin görüntüsü hələ avtomatik şərh edilmir."
            } else {
                status.text = "Ekran icazəsi verilmədi."
                Toast.makeText(this, "Ekran paylaşımı icazəsi ləğv edildi", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
